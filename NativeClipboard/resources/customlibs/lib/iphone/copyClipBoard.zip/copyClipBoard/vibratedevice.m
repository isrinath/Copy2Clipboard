//
//  vibratedevice.m
//  DeviceVibrate
//
//  Created by Zabiullah on 15/08/16.
//  Copyright © 2016 Zabiullah. All rights reserved.
//

#import "vibratedevice.h"
#import <AudioToolbox/AudioToolbox.h>
#import <UIKit/UIPasteboard.h>
@implementation vibratedevice

+(void) vibrateMyDevice
{
    AudioServicesPlaySystemSound (kSystemSoundID_Vibrate);
    
}
+(NSString*)copy2ClipBoard : (NSString *)input
{
  //  AudioServicesPlaySystemSound (kSystemSoundID_Vibrate);
  //  input = @"Hello world";
   // NSLog(input);
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = input;
    
    return input;
}



@end
