//
//
//  Copy2ClipBoard
//
//  Created by Srinath Adepu on 08/10/16.
//


#import <Foundation/Foundation.h>

@interface copyToClipboard : NSObject

+(NSString*) setTextToClipboard : (NSString *)input;

@end
